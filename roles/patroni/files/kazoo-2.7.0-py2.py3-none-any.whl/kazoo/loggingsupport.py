BLATHER = 5  # log level for low-level debugging
